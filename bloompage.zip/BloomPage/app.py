from flask import Flask
from core.routes import main
from config import UPLOAD_FOLDER

app = Flask(__name__)
app.secret_key = "glowfolio_secret"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

app.register_blueprint(main)

if __name__ == "__main__":
    app.run(debug=True)
