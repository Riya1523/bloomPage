import zipfile, os, uuid
from flask import send_file

def export_html():
    os.makedirs("exports/html", exist_ok=True)

    zip_name = f"GlowFolio_{uuid.uuid4()}.zip"
    zip_path = f"exports/html/{zip_name}"

    with zipfile.ZipFile(zip_path, "w") as zipf:
        zipf.write("templates/preview.html", "index.html")
        zipf.write("static/css/main.css", "main.css")

    return send_file(zip_path, as_attachment=True)
