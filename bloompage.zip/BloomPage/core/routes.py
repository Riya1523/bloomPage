from flask import Blueprint, render_template, request, send_file
from .utils import save_image
import zipfile, uuid, os

main = Blueprint("main", __name__)

@main.route("/")
def wizard():
    return render_template("wizard.html")

@main.route("/preview", methods=["POST"])
def preview():
    data = request.form.to_dict()
    photo = save_image(request.files.get("photo"))

    # Section order
    order = data.get("order", "")
    sections = order.split(",")

    layout = data.get("layout", "left")

    return render_template(
        "preview.html",
        data=data,
        photo=photo,
        sections=sections,
        layout=layout
    )

@main.route("/download/html", methods=["POST"])
def download_html():
    os.makedirs("exports", exist_ok=True)
    zip_name = f"GlowFolio_{uuid.uuid4()}.zip"
    zip_path = f"exports/{zip_name}"

    with zipfile.ZipFile(zip_path, "w") as zipf:
        zipf.write("templates/preview.html", "index.html")
        zipf.write("static/css/main.css", "main.css")

    return send_file(zip_path, as_attachment=True)
