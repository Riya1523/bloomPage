const panels = document.querySelectorAll(".panel");
const steps = document.querySelectorAll(".step");
let index = 0;

function updateUI() {
  panels.forEach(p => p.classList.remove("active"));
  steps.forEach(s => s.classList.remove("active"));
  panels[index].classList.add("active");
  steps[index].classList.add("active");
}

document.getElementById("next").onclick = () => {
  if (index < panels.length - 1) index++;
  updateUI();
};

document.getElementById("prev").onclick = () => {
  if (index > 0) index--;
  updateUI();
};

updateUI();
